No files could be converted in this environment.
Reasons may include missing system libraries for HEIC/AVIF support.
I attempted pillow_heif and pyheif methods.
If you want, I can try again or provide PNG fallbacks instead.
